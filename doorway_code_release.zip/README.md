# Doorway analysis code (for JRSI submission)

This repository contains the analysis notebooks and a minimal runner to reproduce the derived outputs reported in the manuscript.

## Contents

- `notebooks/doorway.ipynb` and `notebooks/doorway_new.ipynb`: analysis notebooks used in the study.
- `src/doorway/run_analysis.py`: executes a selected notebook end-to-end and saves an executed copy to `outputs/`.

## Quickstart (local)

1. Create an environment and install dependencies:

   ```bash
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```

2. Run the analysis notebook (writes an executed notebook into `outputs/`):

   ```bash
   python -m doorway.run_analysis --notebook notebooks/doorway_new.ipynb --out_dir outputs --timeout 3600
   ```

Notes:
- The notebooks were originally authored for Google Colab / Google Drive. If a notebook still uses Colab-only paths,
  update those cells to read your dataset location from a variable/argument (recommended) rather than an absolute Drive path.
- The runner sets `OUT_DIR` as an environment variable; you can use it inside the notebook to route saved figures/tables.

## License

MIT License (see `LICENSE`).

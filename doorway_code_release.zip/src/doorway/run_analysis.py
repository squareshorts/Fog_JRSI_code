"""Doorway analysis runner.

This is a thin wrapper intended to make the workflow reproducible outside notebooks.
It executes the selected notebook end-to-end and writes outputs into the requested directory.

Usage:
  python -m doorway.run_analysis --notebook notebooks/doorway_new.ipynb --out_dir outputs

Notes:
  - The notebooks were originally authored for Google Colab/Drive. This runner sets an
    OUTPUT directory environment variable (OUT_DIR) that you can read inside the notebook.
  - If your notebook still hardcodes Colab paths, edit the notebook to use the provided args.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path

import nbformat
from nbconvert.preprocessors import ExecutePreprocessor

def execute_notebook(nb_path: Path, out_dir: Path, timeout: int = 3600) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    os.environ["OUT_DIR"] = str(out_dir.resolve())

    nb = nbformat.read(str(nb_path), as_version=4)
    ep = ExecutePreprocessor(timeout=timeout, kernel_name="python3")
    # Execute in the notebook's directory so relative paths work
    ep.preprocess(nb, {"metadata": {"path": str(nb_path.parent)}})

    executed_path = out_dir / (nb_path.stem + "_executed.ipynb")
    nbformat.write(nb, str(executed_path))
    return executed_path

def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--notebook", type=str, default="notebooks/doorway_new.ipynb",
                   help="Path to the notebook to execute.")
    p.add_argument("--out_dir", type=str, default="outputs",
                   help="Directory to write executed notebook and any saved figures/tables.")
    p.add_argument("--timeout", type=int, default=3600, help="Execution timeout (seconds).")
    args = p.parse_args()

    nb_path = Path(args.notebook)
    out_dir = Path(args.out_dir)
    executed = execute_notebook(nb_path, out_dir, timeout=args.timeout)
    print(f"Executed notebook saved to: {executed}")

if __name__ == "__main__":
    main()
